package com.henu.thirdtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    private NotificationManager manager;
    private Context contex;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            String channelld="mybutton1";
            String channelName="发送广播消息";
            int improtance=NotificationManager.IMPORTANCE_HIGH;
            createNotificationChannel(channelld,channelName,improtance);
        }
        Button mybutton1=findViewById(R.id.mybutton1);
        mybutton1.setOnClickListener(this);
        Button mybutton2=findViewById(R.id.mybutton2);
        mybutton2.setOnClickListener(this);
    }
    @TargetApi(Build.VERSION_CODES.O)
    private void createNotificationChannel(String channelld, String channelName, int improtance) {
        NotificationChannel channel=new NotificationChannel(channelld,channelName,improtance);
        NotificationManager notificationManager=(NotificationManager)getSystemService(
                NOTIFICATION_SERVICE
        );
        notificationManager.createNotificationChannel(channel);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.mybutton1:
                Notification notification=new NotificationCompat.Builder(this,"mybutton1").
                        setAutoCancel(true).
                        setContentTitle(getString(R.string.app_name)).
                        setContentText("2012020028_扶靖棋").
                        setWhen(System.currentTimeMillis()).
                        setSmallIcon(R.mipmap.ic_launcher).setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher)).build();
                manager.notify(1,notification);
                break;
            case R.id.mybutton2:
                manager.cancel(1);
        }
    }
}
