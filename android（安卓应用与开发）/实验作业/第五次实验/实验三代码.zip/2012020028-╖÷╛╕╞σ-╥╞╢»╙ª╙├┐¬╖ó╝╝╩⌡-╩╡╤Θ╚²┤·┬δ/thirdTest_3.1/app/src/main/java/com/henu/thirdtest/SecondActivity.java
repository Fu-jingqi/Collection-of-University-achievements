package com.henu.thirdtest;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;


public class SecondActivity extends AppCompatActivity {
    private int index;

    private String name=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        final  Intent intent1;
        intent1=getIntent();
        name=intent1.getStringExtra("name");
        AlertDialog dialog=new AlertDialog.Builder(SecondActivity.this)
                .setMessage("删除"+name+"的记录吗？")
                .setNegativeButton("取消",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                .setPositiveButton("确定",
                        new DialogInterface.OnClickListener() {
                            Intent intent=new Intent();
                            public void onClick(DialogInterface dialog, int which) {
                                setResult(2,intent);//设置子界面的编号并返回
                                finish();

                            }

                        })
                .create();
        dialog.show();
    }
}
