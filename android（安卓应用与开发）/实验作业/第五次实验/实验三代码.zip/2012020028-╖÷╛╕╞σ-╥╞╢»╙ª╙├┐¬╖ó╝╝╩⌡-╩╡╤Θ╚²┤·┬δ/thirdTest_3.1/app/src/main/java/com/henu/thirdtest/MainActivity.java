package com.henu.thirdtest;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private String a;//全局变量，记录点击哪一项
    private   ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.MyListView);
        List<String>list=new ArrayList<String>();
        list.add("张三");
        list.add("李四");
        list.add("狗子");
        list.add("小王");
        list.add("小红");
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String mag =adapter.getItem(position);
                a = mag;
                final Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                intent.putExtra("name", mag.toString());
                startActivityForResult(intent, 1);
            }
        });}

    protected void onActivityResult(int requestCode,int resultCode, Intent data) {//requestCode 为父界面的编号
        //resultCode 为子界面的返回编号
        //data可以使传递的值
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 2) {
            adapter.remove(a);
        }

    }
}